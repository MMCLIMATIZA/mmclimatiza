MM CLIMATIZA - Instruções rápidas para publicar no GitHub Pages

Arquivos incluídos:
- index.html  (site pronto; utiliza arquivo 'logo.png' como logotipo)
- README.txt  (este arquivo)
 
IMPORTANTE:
1) Substitua o arquivo 'logo.png' pelo seu logo real (formato PNG/JPG) e mantenha o nome 'logo.png'.
2) Vá no GitHub: crie um repositório público (ex: mmclimatiza), clique em Add file → Upload files e envie:
   - index.html
   - logo.png (sua logo)
   - README.txt (opcional)
3) Após enviar, vá em Settings → Pages, escolha branch 'main' e root '/', clique em Save.
4) Aguarde alguns segundos/minutos — o link do site será: https://<seu-usuario>.github.io/<nome-do-repositorio>/

DICA para Google Ads:
- Use o link do GitHub Pages como URL final ao criar os anúncios.
- Teste o botão WhatsApp para garantir que abre corretamente no celular.
- Se quiser, posso preparar o texto do anúncio otimizado (títulos e descrições) também.

Se quiser, gero um arquivo .zip com tudo para download — já incluí aqui (veja arquivo mm_climatiza_site.zip).
